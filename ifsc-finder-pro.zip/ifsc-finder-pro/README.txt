=== IFSC Finder Pro ===
Contributors: Rohan  
Tags: IFSC, bank codes, bank finder, India, shortcode  
Requires at least: 5.8  
Tested up to: 6.3  
Requires PHP: 7.2  
Stable tag: 1.0  
License: Commercial  
 

== Description ==  
IFSC Finder Pro is a lightweight, responsive WordPress plugin that allows users to find Indian bank IFSC codes and branch details using an intuitive dropdown or IFSC code search.

== Features ==  
* Search by dropdown: Bank → State → City/District → Branch  
* Search by IFSC code  
* Works without third-party APIs  
* Easy to integrate with shortcode  
* Fast, clean UI

== Installation ==  
1. Upload the plugin ZIP via WordPress dashboard  
2. Activate the plugin  
3. Use the shortcode `[ifsc_finder_pro]` on any page or post

== Changelog ==  
= 1.0 =  
* Initial release
