jQuery(document).ready(function($) {
    // Toggle between search modes
    $('input[name="search_mode"]').change(function() {
        var mode = $(this).val();
        if (mode === 'dropdown') {
            $('#dropdown-search').removeClass('hidden');
            $('#ifsc-search').addClass('hidden');
            $('#ifsc-result').addClass('hidden');
            $('#ifsc-error').addClass('hidden');
        } else {
            $('#dropdown-search').addClass('hidden');
            $('#ifsc-search').removeClass('hidden');
            $('#ifsc-result').addClass('hidden');
            $('#ifsc-error').addClass('hidden');
        }
    });

    // Load dropdown data via AJAX on page load
    $.ajax({
        url: ifscfp_params.ajax_url,
        method: 'POST',
        data: {
            action: 'ifscfp_get_data',
            nonce: ifscfp_params.nonce
        },
        success: function(response) {
            if (response.success) {
                var data = response.data;
                
                // Populate Bank Name dropdown
                $.each(data.banks, function(index, name) {
                    $('#bank-name').append('<option value="' + name + '">' + name + '</option>');
                });
                
                // When Bank Name changes
                $('#bank-name').change(function() {
                    var bank = $(this).val();
                    $('#state').prop('disabled', !bank).empty().append('<option value="">Select State</option>');
                    $('#city').prop('disabled', true).empty().append('<option value="">Select City/District</option>');
                    $('#branch').prop('disabled', true).empty().append('<option value="">Select Branch</option>');
                    $('#ifsc-result').addClass('hidden');
                    $('#ifsc-error').addClass('hidden');
                    
                    if (bank) {
                        $.each(data.states, function(index, name) {
                            $('#state').append('<option value="' + name + '">' + name + '</option>');
                        });
                    }
                });
                
                // When State changes
                $('#state').change(function() {
                    var state = $(this).val();
                    var bank = $('#bank-name').val();
                    $('#city').prop('disabled', !state).empty().append('<option value="">Select City/District</option>');
                    $('#branch').prop('disabled', true).empty().append('<option value="">Select Branch</option>');
                    $('#ifsc-result').addClass('hidden');
                    $('#ifsc-error').addClass('hidden');
                    
                    if (state && bank) {
                        var cities = data.cities[state] || [];
                        $.each(cities, function(index, name) {
                            $('#city').append('<option value="' + name + '">' + name + '</option>');
                        });
                    }
                });
                
                // When City changes
                $('#city').change(function() {
                    var city = $(this).val();
                    var bank = $('#bank-name').val();
                    $('#branch').prop('disabled', !city).empty().append('<option value="">Select Branch</option>');
                    $('#ifsc-result').addClass('hidden');
                    $('#ifsc-error').addClass('hidden');
                    
                    if (city && bank) {
                        var branches = data.branches[bank] && data.branches[bank][city] ? data.branches[bank][city] : [];
                        $.each(branches, function(index, branch) {
                            $('#branch').append('<option value="' + branch.ifsc + '" data-name="' + branch.name + '">' + branch.name + '</option>');
                        });
                    }
                });
                
                // When Branch changes
                $('#branch').change(function() {
                    var ifsc = $(this).val();
                    var bank = $('#bank-name').val();
                    var state = $('#state').val();
                    var city = $('#city').val();
                    var branch_name = $('#branch option:selected').data('name');
                    
                    if (ifsc && bank && state && city && branch_name) {
                        $('#result-bank').text(bank);
                        $('#result-branch').text(branch_name);
                        $('#result-state').text(state);
                        $('#result-city').text(city);
                        $('#result-ifsc').text(ifsc);
                        $('#ifsc-result').removeClass('hidden');
                        $('#ifsc-error').addClass('hidden');
                    } else {
                        $('#ifsc-result').addClass('hidden');
                        $('#ifsc-error').addClass('hidden');
                    }
                });
            } else {
                $('#ifsc-error').removeClass('hidden');
                console.error('IFSC Finder Pro: Failed to load data - ' + (response.data || 'Unknown error'));
            }
        },
        error: function() {
            $('#ifsc-error').removeClass('hidden');
            console.error('IFSC Finder Pro: AJAX error');
        }
    });

    // Handle IFSC code search
    $('#ifsc-search-btn').click(function() {
        var ifsc_code = $('#ifsc-code').val().trim();
        if (!ifsc_code) {
            $('#ifsc-error').text('Please enter an IFSC code.').removeClass('hidden');
            $('#ifsc-result').addClass('hidden');
            return;
        }

        $.ajax({
            url: ifscfp_params.ajax_url,
            method: 'POST',
            data: {
                action: 'ifscfp_search_ifsc',
                nonce: ifscfp_params.nonce,
                ifsc_code: ifsc_code
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    $('#result-bank').text(data.bank_name);
                    $('#result-branch').text(data.branch_name);
                    $('#result-state').text(data.state);
                    $('#result-city').text(data.city);
                    $('#result-ifsc').text(data.ifsc_code);
                    $('#ifsc-result').removeClass('hidden');
                    $('#ifsc-error').addClass('hidden');
                } else {
                    $('#ifsc-error').text(response.data || 'No bank details found.').removeClass('hidden');
                    $('#ifsc-result').addClass('hidden');
                }
            },
            error: function() {
                $('#ifsc-error').text('An error occurred while searching.').removeClass('hidden');
                $('#ifsc-result').addClass('hidden');
                console.error('IFSC Finder Pro: AJAX error on IFSC search');
            }
        });
    });
});