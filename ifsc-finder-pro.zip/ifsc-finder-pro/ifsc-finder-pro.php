<?php
/*
Plugin Name: IFSC Finder Pro
Description: Find bank IFSC codes using dropdowns and CSV upload.
Version: 1.0.21
Author: Rohan Kumar Jha
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Create database table on plugin activation
register_activation_hook(__FILE__, 'ifscfp_create_db');
function ifscfp_create_db() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ifscfp_data';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        bank_name varchar(255) NOT NULL,
        branch_name varchar(255) NOT NULL,
        city varchar(255) NOT NULL,
        state varchar(255) NOT NULL,
        ifsc_code varchar(11) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $result = dbDelta($sql);
    
    error_log('IFSC Finder Pro: Database creation attempted. Result: ' . print_r($result, true));
    
    // Insert sample data if table is empty
    if ($wpdb->get_var("SELECT COUNT(*) FROM $table_name") == 0) {
        $sample_data = [
            ['bank_name' => 'HDFC Bank', 'branch_name' => 'Andheri Branch', 'city' => 'Mumbai', 'state' => 'Maharashtra', 'ifsc_code' => 'HDFC0000123'],
            ['bank_name' => 'HDFC Bank', 'branch_name' => 'Bandra Branch', 'city' => 'Mumbai', 'state' => 'Maharashtra', 'ifsc_code' => 'HDFC0000456'],
            ['bank_name' => 'ICICI Bank', 'branch_name' => 'Marine Drive Branch', 'city' => 'Mumbai', 'state' => 'Maharashtra', 'ifsc_code' => 'ICIC0000567'],
            ['bank_name' => 'State Bank of India', 'branch_name' => 'Fort Branch', 'city' => 'Mumbai', 'state' => 'Maharashtra', 'ifsc_code' => 'SBIN0000156'],
        ];
        foreach ($sample_data as $row) {
            $wpdb->insert($table_name, $row);
        }
        error_log('IFSC Finder Pro: Sample data inserted');
    }
}

// Create upload directory on plugin activation
register_activation_hook(__FILE__, 'ifscfp_create_upload_dir');
function ifscfp_create_upload_dir() {
    $upload_dir = wp_upload_dir();
    $ifsc_dir = $upload_dir['basedir'] . '/ifsc-finder-pro';
    if (!file_exists($ifsc_dir)) {
        wp_mkdir_p($ifsc_dir);
        error_log('IFSC Finder Pro: Created upload directory at ' . $ifsc_dir);
    }
}

// Load styles and scripts
function ifscfp_load_files() {
    wp_enqueue_style('ifscfp-tailwind', 'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css', [], '2.2.19');
    wp_enqueue_style('ifscfp-style', plugin_dir_url(__FILE__) . 'style.css', [], '1.0.21');
    wp_enqueue_script('ifscfp-script', plugin_dir_url(__FILE__) . 'script.js', ['jquery'], '1.0.21', true);
    
    // Pass AJAX URL and nonce to JavaScript
    wp_localize_script('ifscfp-script', 'ifscfp_params', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ifscfp_nonce'),
    ]);
}
add_action('wp_enqueue_scripts', 'ifscfp_load_files');
add_action('admin_enqueue_scripts', 'ifscfp_load_files');

// Add admin menu
add_action('admin_menu', 'ifscfp_admin_menu');
function ifscfp_admin_menu() {
    error_log('IFSC Finder Pro: Registering admin menu');
    add_menu_page(
        'IFSC Finder Pro',
        'IFSC Finder Pro',
        'manage_options',
        'ifsc-finder-pro',
        'ifscfp_admin_page',
        'dashicons-upload',
        80
    );
}

// Admin page content
function ifscfp_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ifscfp_data';
    
    error_log('IFSC Finder Pro: Admin page loaded');
    
    // Handle CSV upload
    if (isset($_POST['ifscfp_upload_csv']) && check_admin_referer('ifscfp_upload_csv')) {
        if (isset($_FILES['ifscfp_csv_file']) && $_FILES['ifscfp_csv_file']['error'] == 0) {
            $file = $_FILES['ifscfp_csv_file']['tmp_name'];
            $ext = pathinfo($_FILES['ifscfp_csv_file']['name'], PATHINFO_EXTENSION);
            if (strtolower($ext) !== 'csv') {
                echo '<div class="notice notice-error"><p>Please upload a valid CSV file.</p></div>';
            } else {
                // Move file to plugin-specific directory
                $upload_dir = wp_upload_dir();
                $ifsc_dir = $upload_dir['basedir'] . '/ifsc-finder-pro';
                $filename = uniqid('ifscfp_') . '.csv';
                $new_file = $ifsc_dir . '/' . $filename;
                
                if (!file_exists($ifsc_dir)) {
                    wp_mkdir_p($ifsc_dir);
                }
                
                if (move_uploaded_file($file, $new_file)) {
                    $handle = fopen($new_file, 'r');
                    if ($handle === false) {
                        echo '<div class="notice notice-error"><p>Failed to read CSV file.</p></div>';
                        @unlink($new_file);
                    } else {
                        $headers = fgetcsv($handle);
                        fclose($handle);
                        if ($headers === false || empty($headers) || count($headers) < 5) {
                            echo '<div class="notice notice-error"><p>CSV file is empty or has insufficient columns (requires at least 5).</p></div>';
                            @unlink($new_file);
                        } else {
                            set_transient('ifscfp_csv_headers', $headers, 24 * HOUR_IN_SECONDS);
                            set_transient('ifscfp_csv_file', $new_file, 24 * HOUR_IN_SECONDS);
                            echo '<div class="notice notice-success"><p>CSV uploaded. Please map the columns below.</p></div>';
                        }
                    }
                } else {
                    echo '<div class="notice notice-error"><p>Failed to move CSV file to upload directory.</p></div>';
                }
            }
        } else {
            echo '<div class="notice notice-error"><p>Error uploading CSV file. Ensure file size is under ' . ini_get('upload_max_filesize') . '.</p></div>';
        }
    }
    
    // Handle column mapping and data import
    if (isset($_POST['ifscfp_update_data']) && check_admin_referer('ifscfp_update_data')) {
        $mapping = [
            'bank_name' => sanitize_text_field($_POST['map_bank_name']),
            'branch_name' => sanitize_text_field($_POST['map_branch_name']),
            'city' => sanitize_text_field($_POST['map_city']),
            'state' => sanitize_text_field($_POST['map_state']),
            'ifsc_code' => sanitize_text_field($_POST['map_ifsc_code']),
        ];
        
        // Validate mapping
        $missing = array_filter($mapping, function($value) { return empty($value); });
        if (!empty($missing)) {
            echo '<div class="notice notice-error"><p>Please map all fields.</p></div>';
        } else {
            $file = get_transient('ifscfp_csv_file');
            if ($file && file_exists($file)) {
                $wpdb->query("TRUNCATE TABLE $table_name");
                
                $handle = fopen($file, 'r');
                if ($handle === false) {
                    echo '<div class="notice notice-error"><p>Failed to read CSV file during import.</p></div>';
                } else {
                    $headers = fgetcsv($handle);
                    $row_count = 0;
                    while (($row = fgetcsv($handle)) !== false) {
                        $data = [];
                        foreach ($mapping as $field => $header) {
                            $index = array_search($header, $headers);
                            if ($index !== false && isset($row[$index])) {
                                $value = sanitize_text_field($row[$index]);
                                // Normalize case to uppercase for consistency
                                $data[$field] = strtoupper($value);
                            }
                        }
                        // Log the data being inserted
                        error_log('IFSC Finder Pro: Attempting to insert row: ' . print_r($data, true));
                        if (!empty($data['bank_name']) && !empty($data['ifsc_code']) && !empty($data['branch_name']) && !empty($data['city']) && !empty($data['state'])) {
                            $result = $wpdb->insert($table_name, $data);
                            if ($result === false) {
                                error_log('IFSC Finder Pro: Failed to insert row: ' . $wpdb->last_error);
                            } else {
                                $row_count++;
                            }
                        } else {
                            error_log('IFSC Finder Pro: Skipped row due to missing fields: ' . print_r($data, true));
                        }
                    }
                    fclose($handle);
                    delete_transient('ifscfp_csv_file');
                    delete_transient('ifscfp_csv_headers');
                    @unlink($file);
                    echo '<div class="notice notice-success"><p>Data updated successfully! Imported ' . $row_count . ' rows.</p></div>';
                }
            } else {
                echo '<div class="notice notice-error"><p>CSV file not found or expired. Please upload the file again.</p></div>';
            }
        }
    }
    
    ?>
    <div class="wrap">
        <h1>IFSC Finder Pro</h1>
        <div class="max-w-lg bg-white p-6 rounded-lg shadow-lg mt-4">
            <h2 class="text-lg font-bold mb-4">User Guide</h2>
            <ol class="list-decimal pl-5 space-y-2 text-gray-700">
                <li><strong>Activate Plugin</strong>: Go to Plugins > Installed Plugins, find IFSC Finder Pro, and click Activate.</li>
                <li><strong>Upload CSV</strong>: In this page, upload a CSV with columns: Bank Name, Branch Name, City/District, State, IFSC Code. Example:
                    <pre class="bg-gray-100 p-2 rounded text-sm">Bank Name,Branch Name,City/District,State,IFSC Code
Axis Bank,Kalyan Branch,Kalyan,Maharashtra,UTIB0001234</pre>
                </li>
                <li><strong>Map Columns</strong>: Map CSV columns to plugin fields and click Update Data.</li>
                <li><strong>Add Shortcode</strong>: Go to Pages > Add New, add [ifsc_finder] in a Shortcode block, and publish.</li>
                <li><strong>View Page</strong>: Visit the page to find IFSC codes in two ways:
                    <ul class="list-disc pl-5 mt-1">
                        <li><strong>Search by Dropdown</strong>: Select bank details (Bank Name, State, City/District, Branch) from the dropdowns to see the IFSC code in a table.</li>
                        <li><strong>Search by IFSC Code</strong>: Select the "Search by IFSC Code" option, enter an IFSC code (e.g., UTIB0001234), and click Search to view the bank details in a table.</li>
                    </ul>
                </li>
                <li><strong>Troubleshooting</strong>: Ensure CSV has 5 columns, file size under 2MB. Check wp-content/debug.log if errors occur.</li>
            </ol>
        </div>
        <form method="post" enctype="multipart/form-data" class="max-w-lg bg-white p-6 rounded-lg shadow-lg mt-4">
            <?php wp_nonce_field('ifscfp_upload_csv'); ?>
            <h2 class="text-lg font-bold mb-4">Upload CSV File</h2>
            <p>Upload a CSV file with columns: Bank Name, Branch Name, City/District, State, IFSC Code.</p>
            <input type="file" name="ifscfp_csv_file" accept=".csv" class="mt-2">
            <button type="submit" name="ifscfp_upload_csv" class="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Upload CSV</button>
        </form>
        
        <?php if ($headers = get_transient('ifscfp_csv_headers')): ?>
            <form method="post" class="max-w-lg bg-white p-6 rounded-lg shadow-lg mt-4">
                <?php wp_nonce_field('ifscfp_update_data'); ?>
                <h2 class="text-lg font-bold mb-4">Map CSV Columns</h2>
                <p>Map the CSV columns to the plugin fields. All fields are required.</p>
                <?php
                $fields = [
                    'bank_name' => 'Bank Name',
                    'branch_name' => 'Branch Name',
                    'city' => 'City/District',
                    'state' => 'State',
                    'ifsc_code' => 'IFSC Code',
                ];
                foreach ($fields as $key => $label) {
                    ?>
                    <div class="mb-4">
                        <label for="map_<?php echo $key; ?>" class="block text-sm font-medium"><?php echo $label; ?> (Required)</label>
                        <select name="map_<?php echo $key; ?>" id="map_<?php echo $key; ?>" class="w-full p-2 border rounded-md mt-1">
                            <option value="">Select Column</option>
                            <?php
                            foreach ($headers as $header) {
                                $selected = (strtolower($header) == strtolower($label) || strpos(strtolower($header), strtolower($key)) !== false) ? 'selected' : '';
                                echo '<option value="' . esc_attr($header) . '" ' . $selected . '>' . esc_html($header) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <?php
                }
                ?>
                <button type="submit" name="ifscfp_update_data" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Update Data</button>
            </form>
        <?php endif; ?>
    </div>
    <?php
}

// AJAX handler for dropdown data
add_action('wp_ajax_ifscfp_get_data', 'ifscfp_get_data');
add_action('wp_ajax_nopriv_ifscfp_get_data', 'ifscfp_get_data');
function ifscfp_get_data() {
    check_ajax_referer('ifscfp_nonce', 'nonce');
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'ifscfp_data';
    
    // Use UPPER() for case-insensitive comparison
    $banks = $wpdb->get_results("SELECT DISTINCT UPPER(bank_name) as bank_name FROM $table_name ORDER BY bank_name");
    $states = $wpdb->get_results("SELECT DISTINCT UPPER(state) as state FROM $table_name ORDER BY state");
    $cities = $wpdb->get_results("SELECT DISTINCT UPPER(state) as state, UPPER(city) as city FROM $table_name ORDER BY city");
    $branches = $wpdb->get_results("SELECT UPPER(bank_name) as bank_name, UPPER(city) as city, branch_name, ifsc_code FROM $table_name");
    
    $data = [
        'banks' => array_column($banks, 'bank_name'),
        'states' => array_column($states, 'state'),
        'cities' => [],
        'branches' => [],
    ];
    
    if (empty($data['banks'])) {
        wp_send_json_error('No data available in the database.');
    }
    
    foreach ($cities as $city) {
        $data['cities'][$city->state][] = $city->city;
    }
    
    foreach ($branches as $branch) {
        $data['branches'][$branch->bank_name][$branch->city][] = [
            'name' => $branch->branch_name,
            'ifsc' => $branch->ifsc_code,
        ];
    }
    
    // Log the data being sent to frontend
    error_log('IFSC Finder Pro: Data sent to frontend: ' . print_r($data, true));
    
    wp_send_json_success($data);
}

// AJAX handler for IFSC code search
add_action('wp_ajax_ifscfp_search_ifsc', 'ifscfp_search_ifsc');
add_action('wp_ajax_nopriv_ifscfp_search_ifsc', 'ifscfp_search_ifsc');
function ifscfp_search_ifsc() {
    check_ajax_referer('ifscfp_nonce', 'nonce');
    
    $ifsc_code = sanitize_text_field($_POST['ifsc_code']);
    
    if (empty($ifsc_code)) {
        wp_send_json_error('Please enter a valid IFSC code.');
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'ifscfp_data';
    
    $result = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT bank_name, branch_name, city, state, ifsc_code FROM $table_name WHERE ifsc_code = %s LIMIT 1",
            $ifsc_code
        ),
        ARRAY_A
    );
    
    if ($result) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error('No bank details found for the provided IFSC code.');
    }
}

// Frontend form
function ifscfp_show_form() {
    error_log('IFSC Finder Pro: Shortcode [ifsc_finder] called');
    ob_start();
    ?>
    <div class="ifsc-finder-form max-w-lg mx-auto p-4 bg-white rounded-lg shadow-lg">
        <h2 class="text-xl font-bold mb-4 text-center text-gray-800">IFSC Finder Pro</h2>
        <div class="mb-4 text-center">
            <label class="inline-flex items-center mr-4">
                <input type="radio" name="search_mode" value="dropdown" class="form-radio text-blue-600" checked>
                <span class="ml-2 text-gray-700">Search by Dropdown</span>
            </label>
            <label class="inline-flex items-center">
                <input type="radio" name="search_mode" value="ifsc" class="form-radio text-blue-600">
                <span class="ml-2 text-gray-700">Search by IFSC Code</span>
            </label>
        </div>
        <div id="dropdown-search" class="space-y-3">
            <div>
                <label for="bank-name" class="block text-sm font-medium text-gray-700">Bank Name</label>
                <select id="bank-name" name="bank_name" class="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500">
                    <option value="">Select Bank</option>
                </select>
            </div>
            <div>
                <label for="state" class="block text-sm font-medium text-gray-700">State</label>
                <select id="state" name="state" class="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500" disabled>
                    <option value="">Select State</option>
                </select>
            </div>
            <div>
                <label for="city" class="block text-sm font-medium text-gray-700">City/District</label>
                <select id="city" name="city" class="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500" disabled>
                    <option value="">Select City/District</option>
                </select>
            </div>
            <div>
                <label for="branch" class="block text-sm font-medium text-gray-700">Bank Branch</label>
                <select id="branch" name="branch" class="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500" disabled>
                    <option value="">Select Branch</option>
                </select>
            </div>
        </div>
        <div id="ifsc-search" class="space-y-3 hidden">
            <div>
                <label for="ifsc-code" class="block text-sm font-medium text-gray-700">IFSC Code</label>
                <input type="text" id="ifsc-code" name="ifsc_code" class="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="Enter IFSC Code (e.g., HDFC0000123)">
                <button id="ifsc-search-btn" class="mt-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Search</button>
            </div>
        </div>
        <div id="ifsc-result" class="mt-4 hidden">
            <table class="w-full border-collapse border border-gray-300">
                <tbody>
                    <tr>
                        <td class="border border-gray-300 p-2 font-medium">Bank Name</td>
                        <td id="result-bank" class="border border-gray-300 p-2"></td>
                    </tr>
                    <tr>
                        <td class="border border-gray-300 p-2 font-medium">Bank Branch Name</td>
                        <td id="result-branch" class="border border-gray-300 p-2"></td>
                    </tr>
                    <tr>
                        <td class="border border-gray-300 p-2 font-medium">State Name</td>
                        <td id="result-state" class="border border-gray-300 p-2"></td>
                    </tr>
                    <tr>
                        <td class="border border-gray-300 p-2 font-medium">City/District Name</td>
                        <td id="result-city" class="border border-gray-300 p-2"></td>
                    </tr>
                    <tr>
                        <td class="border border-gray-300 p-2 font-medium">Bank IFSC Code</td>
                        <td id="result-ifsc" class="border border-gray-300 p-2"></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div id="ifsc-error" class="mt-4 text-red-600 hidden">
            No data available. Please upload a valid CSV file in the admin panel.
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('ifsc_finder', 'ifscfp_show_form');
?>